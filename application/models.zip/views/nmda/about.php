<div class="body">
<div class="wrap">
<div class="content">
	<div class="about-main">
	  <div class="cont-grid">
       	<h3>About &nbsp;<a>Academic</a></h3>
          
       <p style="font-size: 14px;font-family: cursive;">
       <br>
       On behalf of my committee and all the members of education society. I thank you for your interest and welome you to share the dream of creating an institutional landmark in New Modern Defence Academy.</p>
         	
      	</div>
      	<div class="cont-grid-img">
     		<img src="<?php echo base_url();?>assets/nmda/images/academy.png" alt=""  />
     	</div>
   <p style="font-size: 14px;font-family: cursive;">&nbsp;&nbsp;&nbsp; I don't know how many times I've studied for a test for hours and then gone to take it and it seemed like a foreign language to me. It's like you get done and feel as though some alien creature overtook your mind during the test and erased all the information you had stored in there. So you get done and walk home mesmerized, amazed you even remember where home is.</p>
	</div>
					<div class="cont-btm-right">
					<div class="cont-right-grid">
					<h4>About Director</h4>
					<div class="date">
						<img src="<?php echo base_url();?>assets/nmda/images/shyamjee.png" alt=""  />
					</div>
					<div class="para">
					 <p style="font-size: 14px;font-family: cursive;">
    
       Success is Achieved by those individuals, who have the capacity to Dream Big provide wings to their dreams and remain focused till they Achieve the ultimate.” So keep meet fire burning inside you till you meet your Goals.</p>
         <p style="font-size: 14px;font-family: cursive;">I don't know how many times I've studied for a test for hours and then gone to take it and it seemed like a foreign language to me. It's like you get done and feel as though some alien creature overtook your mind during the test and erased all the information you had stored in there. So you get done and walk home mesmerized, amazed you even remember where home is.</p>
         <h6 style="float:right">Shyamjee Kushwaha</h6>
					</div>
						<div class="clear"></div>
					</div>
				
					
				
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			</div>
			</div>