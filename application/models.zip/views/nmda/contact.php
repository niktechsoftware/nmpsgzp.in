<div class="body">
<div class="wrap">
<div class="content">
	<div class="contact-left">
	<h3>Contact Info</h3>
	<div class="map">
		<iframe width="358" height="180" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=america&amp;aq=&amp;sll=14.440706,80.001154&amp;sspn=0.039274,0.075188&amp;ie=UTF8&amp;hq=&amp;hnear=United+States&amp;ll=37.09024,-95.712891&amp;spn=32.912722,76.992187&amp;t=m&amp;z=5&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=america&amp;aq=&amp;sll=14.440706,80.001154&amp;sspn=0.039274,0.075188&amp;ie=UTF8&amp;hq=&amp;hnear=United+States&amp;ll=37.09024,-95.712891&amp;spn=32.912722,76.992187&amp;t=m&amp;z=5" style="color:#999;text-align:left">View Larger Map</a></small>
	</div>	
	<div class="grids">
	<h4>New Modern Defence Academy</h4>
	<span>Phullanpur - Ghazipur</span><br>
	<span>Mob: +91 945 100 7575</span> <br>
	<span>email&nbsp;:&nbsp;<a href="">info@nmps.in</a></span>
	</div>
	</div>
<div id="registration">
 <h2>Contact</h2>
 <form id="RegisterUserForm" method="post">
 	<fieldset>
         <p>
            <label for="name" style="position: absolute; left: 0px; top: 0px; opacity: 1;" class="infield"> </label>
            <input id="name" name="name" type="text" class="text" value="">
         </p>
               <p>
            <label for="tel" style="position: absolute; left: 0px; top: 0px; opacity: 1;" class="infield"> </label>
            <input id="tel" name="tel" type="tel" class="text" value="">
         </p>
         <p>
            <label for="email" style="position: absolute; left: 0px; top: 0px; opacity: 1;" class="infield"> </label>
            <input id="email" name="email" type="email" class="text" value="">
         </p>
         <p>
            <label for="password" style="position: absolute; left: 0px; top: 0px; opacity: 1;" class="infield"> </label>
            <input id="password" name="password" class="text" type="password">
         </p>
         <div class="contact-btn">
	<input type="submit" value="Send" />
</div>
<div class="clear"></div>
    	</fieldset>
</form>
</div>
<div class="clear"></div>
</div>
</div>
</div>