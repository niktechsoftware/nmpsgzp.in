<div class="body">
<div class="wrap">
	<div class="content">
	<div class="ser-main">
	<h3>OUR Gallery</h3>
    
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/pic1.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/pic1.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/ser-pic1.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/ser-pic1.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/ser-pic2.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/ser-pic2.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/ser-pic3.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/ser-pic3.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/ser-pic4.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/ser-pic4.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
    <div class="grid-list">
    <div style="float:left; margin:20px; padding:10px; height:170px; width:195px; border:1px solid #009;">
            <a class="example-image-link" href="<?php echo base_url();?>assets/nmda/images/ser-pic5.jpg" data-lightbox="example-set" >
               <img src="<?php echo base_url();?>assets/nmda/images/ser-pic5.jpg" style="float:left;" width="160" height="140">
           	</a>
            </div>
	
	<div class="clear"></div>
	</div>
	<script src="<?php echo base_url();?>assets/nmda/lightbox/js/jquery-1.11.0.min.js"></script>
	<script src="<?php echo base_url();?>assets/nmda/lightbox/js/lightbox.js"></script>
	<div class="clear"></div>
	</div>
	</div>
</div>
</div>