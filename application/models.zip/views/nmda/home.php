<div class="body">
<div class="wrap">
<div class="content">
	<div class="cont-btm">
				<div class="cont-btm-left">
					<div class="cont-left-grid">
					<p>
					 <img src="<?php echo base_url();?>assets/nmda/images/shyamjee.png" alt="" style="float:left;" />On behalf of my committee and all the members of education society. I thank you for your interest and welome you to share the dream of creating an institutional landmark in New Modern Defence Academy.
                </p>
                <p>I don't know how many times I've studied for a test for hours and then gone to take it and it seemed like a foreign language to me. It's like you get done and feel as though some alien creature overtook your mind during the test and erased all the information you had stored in there. So you get done and walk home mesmerized, amazed you even remember where home is.</p>
                
                 <h6 style="margin-left:220px">Shyamjee Kushwaha</h6>
                 <h6 style="margin-left:300px">    Director</h6>
				
					<div class="separator"></div>
					</div>
				</div>
				<div class="cont-btm-right">
					<div class="cont-right-grid">
					<h4>Office Timing</h4>
					
					<div class="para">
					<p>Improve and make strong your basic grammatical power and spoken fluency from basic level to highlevel with 9th to 12th whole grammatical materials and notes .</p>
					</div>
					</div>
				
					<div class="para">
					<p>All coaching classes are taught by Mr. Shyamjee Kushwaha</p>
					</div>
				
				</div>
				<div class="clear"></div>
				</div>
	
	<div class="clear"></div>
<div class="clear"></div>
			<div class="banner1">
	<div class="grid-p">
		<h4>Time Table</h4>
	<table width="100%"><tr style="color:#039"><th>Class</th><th>1st Batch &nbsp;(Morning)</th><th>2st Batch &nbsp;(Evening)</th></tr>
	<tr><td>9th</td><td>7:45 am to 8:30 am &nbsp;(Grammer+Book)</td><td>3:15 Pm to 4:15 pm &nbsp;(Grammer+Spoken)</td></tr>
	<tr><td>10th</td><td>7:45 am to 8:30 am &nbsp;(Grammer+Book)</td><td>3:15 Pm to 4:15 pm &nbsp;(Grammer+Spoken)</td></tr>
	<tr><td>11th</td><td>6:45 am to 7:45 am &nbsp;(Grammer+Spoken)</td><td>4:15 Pm to 5:00 pm &nbsp;(Grammer+Book)</td></tr>
	<tr><td>12th</td><td>6:45 am to 7:45 am &nbsp;(Grammer+Spoken)</td><td>4:15 Pm to 5:00 pm &nbsp;(Grammer+Book)</td></tr>
	<tr><td>Competative & Spoken</td><td>6:45 am to 7:45 am &nbsp;(Grammer+Book)</td><td>3:15 Pm to 4:15 pm &nbsp;(Grammer+Spoken)</td></tr>
	</table>
	</div>
	</div>
	<div class="banner2">
	<div class="grid-p">
	<h4>Latets News </h4>
	<marquee direction="up" style="margin-top:1o%; margin-left:1%" width="240" height="280" align="center" scrollamount="2" onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 2, 0);">
			<p>welcome to new modern public school ghazipur.</p>
			</marquee>
		
	</div>
	</div>
				<div class="clear"></div>
	
	<div class="clear"></div>
</div>
</div>
</div>