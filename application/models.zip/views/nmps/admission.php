<div id="main">
        	<!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
            	<div class="container">
                	<h1>Admission Procedure</h1>
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
            	<!--primary starts-->
            
                   <section id="primary" class="content-full-width">
                    
                    <div class="column dt-sc-one-half first">
                        <div class="dt-sc-titled-box">
                            <h4 class="dt-sc-titled-box-title">Admission Procedure</h4>
                            <div class="dt-sc-titled-box-content">
The new academic session commences every year in April. All the students seeking admission to differnt classes are required to register themselves for admission.<br><br>
	Candidates will get their admission formalities completed by the date as fixed by school after depositing the required fees. Birth certificate is to be submitted along with the admission form.<br><br>
	Namesd of the students of the school who remain absent continuously for six days since the start for the new academic session will be struck of the rolls and they will lose al claims for admission.
                       
                            </div>
                        </div>
                    </div>
                    
                    <div class="column dt-sc-one-half">
                        <div class="dt-sc-titled-box green">
                            <h4 class="dt-sc-titled-box-title">Age Limit For Admission </h4>
                            <div class="dt-sc-titled-box-content">
Age limit for admission : The required age of a child for admission to a particular class as on 1st April for the session should be as under.<br><br>
<table>
<tr>
<th>Class</th>
<th>Age</th> 
<tr>
<td>Nursery</td>
<td>21/2 Years</td>
</tr>
<tr>
<td>L.K.G</td>
<td>31/2 Years</td>
</tr>
<tr>
<td>U.K.G</td>
<td>41/2 Years</td>
</tr>
<tr>
<td>Class I	</td>
<td>51/2 Years</td>
</tr>
<tr>
<td>Other Classes</td>
<td>as forward</td>
</tr>
</table> 
Birth certificate from the Municipal corporatioin or local authorities should be submitted at the time of admission.
                                                          
                            </div>
                        </div>
                    </div>
                    </section>
                  <div class="dt-sc-hr"></div>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>