   <div id="main">
        
            <!--slider starts-->
            <div id="slider"> 
                <div id="layerslider_4" class="ls-wp-container" style="width:80%;height:380px;max-width:1920px;margin-right:10%; margin-left:10%; border:8px solid #FFF">
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/bg3.jpg" class="ls-bg" alt="Slide background" />
                        <img class="ls-l" style="top:10px;left:380px;white-space: nowrap;" data-ls="offsetxin:0;delayin:800;easingin:easeOutElastic;skewxin:30;skewyin:30;transformoriginin:50% 0% 50%;offsetxout:0;parallaxlevel:1;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/bring.png" alt="">
                        <img class="ls-l" style="top:200px;left:-375px;z-index:100;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:80;delayin:500;offsetxout:0;offsetyout:-80;" src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/grass.png" alt="">
                        <img class="ls-l" style="top:85px;left:420px;white-space: nowrap;" data-ls="offsetxin:2;delayin:1000;rotatexin:90;rotateyin:90;offsetxout:0;parallaxlevel:-1;" src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/fun.png" alt="">
                        <img class="ls-l" style="top:140px;left:370px;white-space: nowrap;" data-ls="offsetxin:0;delayin:1800;scalexin:3;scaleyin:3;offsetxout:0;parallaxlevel:-2;" src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/two.png" alt="">
                        <img class="ls-l" style="top:140px;left:420px;white-space: nowrap;" data-ls="offsetxin:0;delayin:2200;rotatexin:90;rotateyin:90;offsetxout:0;parallaxlevel:3;" src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/life.png" alt="">
                        <img class="ls-l" style="top:230px;left:420px;white-space: nowrap;" data-ls="delayin:2500;parallaxlevel:-2;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/cup-divider.png" alt="">
                        <img class="ls-l" style="top:280px;left:429px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:-100;delayin:3000;offsetxout:0;offsetyout:100;parallaxlevel:3;" src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/a-trendy-kids.png" alt="">
                      
                        <img class="ls-l" style="top:10px;left:50px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:150;delayin:2700;easingin:easeInBack;offsetxout:0;offsetyout:-150;parallaxlevel:5;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/girl1.png" alt="">
                        
                    </div>
                  
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/black-board.jpg" class="ls-bg" alt="Slide background" />
                        
                    </div>
                    
                    
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/bg2.jpg" class="ls-bg" alt="Slide background" />
                      
                    </div>
                </div>
            </div>
            <!--slider ends-->

            <!--primary starts-->
            <section id="primary" class="content-full-width">
                <!--container starts-->
                <div class="container">
                    
                    <div class="dt-sc-one-fourth column first">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps/images/service1.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">About NMPS</a></h4>
                            <p>A different school besides the unprecedented academic result New Modern Public School is known for inculcating in its students a spiritual outlook and a global vision.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps/images/service2.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Admission Procedure</a></h4>
                            <p>The new academic session commences every year in April. All the students seeking admission to differnt classes are required to register themselves for admission.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps/images/service3.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Admission Age</a></h4>
                            <p> The required age of a child for admission to a particular class as on 1st April for the session should be as under.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps//images/service4.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Office Timing</a></h4>
                            <table><tr><th>morning</th><th>Evening</th></tr><tr><tr><td>6:30 am to 1:15 pm</td><td>3:15 pm to 5:30 pm</td></tr></table>
                        </div>
                    </div>
                    
                </div>
                <!--container ends-->
                <div class="dt-sc-hr"></div>
                  <section class="fullwidth-background dt-sc-parallax-section turquoise-bg">
                    <!--container starts-->
                    <div class="container">
                        <!--dt-sc-one-half starts-->
                        <div class="dt-sc-one-half column first">
                            <h2>Thoughts</h2>
                            <!--dt-sc-one-half starts-->
                            <div class="dt-sc-one-half column first">
                                
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span class="fa fa-glass"> </span> 
                                    </div>
                                    <h4><a href="#"> Shyamjee Kushwaha </a></h4>
                                    <p>Teacher is leaving a vestige of one self in the development of another & surely the student os a bank where you can deposite your most precious treasures.</p>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span class="fa fa-pencil"> </span> 
                                    </div>
                                    <h4><a href="#" > Teacher </a></h4>
                                    <p>A Getway to become professionally skilled in the field of early childhood education.</p>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span class="fa fa-bullseye"> </span> 
                                    </div>
                                   <h4><a href="#">Teacher </a></h4>
                                    <p> Books are the quietest and most constant of friends; they are the most accessible and wisest of counselors, and the most patient of teachers.</p>
                                </div>
                            
                            </div>
                            <!--dt-sc-one-half ends-->
                            
                            <!--dt-sc-one-half starts-->
                            <div class="dt-sc-one-half column">
                                
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span class="fa fa-tachometer"> </span> 
                                    </div>
                                    <h4><a href="#"> one of my students </a></h4>
                                    <p>I don't know how many times I've studied for a test for hours and then gone to take it and it seemed like a foreign language to me.
It's like you get done and feel as though some alien creature overtook your mind during the test and erased all the information you had stored in there.
So you get done and walk home mesmerized, amazed you even remember where home is.</p>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span class="fa fa-magic"> </span> 
                                    </div>
                                    <h4><a href="#" target="_blank"> Teacher </a></h4>
                                    <p>Education is a liberating force, and in our age it is also a democratising force, cutting across the barriers of caste and class, smoothing out inequalities imposes by birth and other circumstances.</p>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>
                              
                            
                            </div>
                            <!--dt-sc-one-half ends-->
                        </div>
                        <!--dt-sc-one-half ends-->
                        
                        <!--dt-sc-one-half starts-->
                        <div class="dt-sc-one-half column">
                            <h2>Mini Gallery</h2>
                            <div class="add-slider-wrapper">
                                <ul class="add-slider">
                                    <li> <img src="<?php echo base_url()?>assets/nmps/images/add1.jpg" alt="" title=""> </li>
                                    <li> <img src="<?php echo base_url()?>assets/nmps/images/add2.jpg" alt="" title=""> </li>
                                    <li> <img src="<?php echo base_url()?>assets/nmps/images/add3.jpg" alt="" title=""> </li>
                                </ul>
                            </div>
                        </div>
                        <!--dt-sc-one-half ends-->
                    </div>
                    <!--container ends-->
                </section>
                <div class="dt-sc-hr"></div>
                <!--container starts-->
               
                <!--container ends-->
                
                <div class="dt-sc-hr"></div>
              
               
              
            </section>
            <!--primary ends-->
        </div>
        