<div id="main">
        	<!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
            	<div class="container">
                	<h1>Salient Feature</h1>
                  
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
            	<!--primary starts-->
            	<section id="primary" class="content-full-width">
                 
                    <div class="column dt-sc-one-half first">
                    	<blockquote>
                          <strong style="color:#309">1.	Regular School :-</strong> Regular classes form L.K.G to class VIII in English Medium are run by the qualities and trained teachers.
                        </blockquote>
                    </div>  
                    
                    <div class="column dt-sc-one-half">
                    	<blockquote class="green">
                           <strong style="color:#309">2.	Test Examination and Rewards :- -</strong> Montly test, terminal and half yearly examination are conducted to keep the child regular in his studies His final promotion is decided on the basis of his performance in these tests and examination. The minimum passing mark is 40% first three rank holders in very class awarded.
                        </blockquote>
                    </div>  
                    
                    <div class="dt-sc-hr-small"></div>
                    <div class="column dt-sc-one-half first">
                    	<blockquote class="mustard">
                            <strong style="color:#309">3.	Spoken English :- </strong>English speaking is compulsory in the school campus. The convert educated teachers take the class to improve their proficiency in English speaking school pays special attention on the studies of week students and arranges extra classes for them without and extra chanrges.
                    </blockquote>
                    </div>  
                    
                    <div class="column dt-sc-one-half">
                    	<blockquote class="burnt-orange">
                           <strong style="color:#309">4.	Personality Development :- </strong>personality development is very necessary for all boys and girls because they are ready to what our social attitude, social norms, behavior and character show the particular criteria. Our teachers are very conscious to cultivate a new concept, idea and manner among all kinds of students.
                    </blockquote>
                    </div>  
                    
                    <div class="dt-sc-hr-small"></div>
                    <div class="column dt-sc-one-half first" style="width:100%">
                    	<blockquote class="blue">
                           <strong style="color:#309">5.	Discipline :-  </strong>Discipline makes a man perfect. it is a good  statement in the favour of all students. Every students and guardians must follow the discipline of this school. Under discipline, there are following rules and regulations.<br>
                    <strong style="color:#FF0">(a)</strong>Students should be well prepared for dress, home work all books and copies,if they do not do so parents must be careful for their children.<br>
                     <strong style="color:#FF0">(b)</strong>When school period is over and children are at home parents must inquire to their children about any, merits an demerits of the school work and home work.<br>
                      <strong style="color:#FF0">(c)</strong>Students must keep their dress nest and clean, they have to come school in dress, what information is given, if they do not follow, they must be punished.<br>
                       <strong style="color:#FF0">(d)</strong>if any students will be absent for a week or many other days. his name will be cancelled in the absence of any information or application, parents must be pay re-admission fee under the communication with offical work.<br>
                        <strong style="color:#FF0">(e)</strong>All students must come to school in time, if they do not follow this rule, they must be punished.<br>
                         <strong style="color:#FF0">(f)</strong>Without dress and admission, students cannot enter the school parents will be responsible for this defect.<br>
                          <strong style="color:#FF0">(g)</strong>Parents must present at parents meeting, if they do not follow this rule, students have to come in the school with their parents.<br>
                           <strong style="color:#FF0">(h)</strong>Parents must pay fees at certain date, if they do not do so they msut send any information or contact without principal to settle the problem.<br>
                    </blockquote>
                    </div>  
                    
                  
                    <div class="dt-sc-hr-small"></div>
                  
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>