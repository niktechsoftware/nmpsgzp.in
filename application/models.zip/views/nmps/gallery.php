<div id="main">
        	<!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
            	<div class="container">
                	<h1>Gallery</h1>
                   
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
            	<!--primary starts-->
            	<section id="primary" class="content-full-width">
                    
                    <!--dt-sc-portfolio-container starts-->
                    <div class="dt-sc-portfolio-container">
                        
                        <div class="portfolio dt-sc-one-fourth column first music">
                            <div class="portfolio-thumb">
                            	<img class="item-mask" src="<?php echo base_url()?>assets/nmps/images/portfolio-mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/1.jpg" alt="" title="">
                                <div class="image-overlay">
                                    <a href="<?php echo base_url()?>assets/nmps/images/1.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                             <div class="portfolio-detail">
                                <div class="portfolio-title">
                                   
                                   
                                </div>
                            </div>
                        </div>
                        
                        <div class="portfolio dt-sc-one-fourth column all">
                            <div class="portfolio-thumb">
                            	<img class="item-mask" src="<?php echo base_url()?>assets/nmps/images/portfolio-mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/2.jpg" alt="" title="">
                                <div class="image-overlay">
                                    <a href="<?php echo base_url()?>assets/nmps/images/2.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="portfolio-detail">
                                <div class="portfolio-title">
                                  
                                </div>
                            </div>
                        </div>
                        
                        <div class="portfolio dt-sc-one-fourth column all innovation">
                            <div class="portfolio-thumb">
                            	<img class="item-mask" src="<?php echo base_url()?>assets/nmps/images/portfolio-mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/3.jpg" alt="" title="">
                                <div class="image-overlay">
                                    <a href="<?php echo base_url()?>assets/nmps/images/3.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="portfolio-detail">
                                <div class="portfolio-title">
                                
                                </div>
                            </div>
                        </div>
                        
                        <div class="portfolio dt-sc-one-fourth column all fun music">
                            <div class="portfolio-thumb">
                            	<img class="item-mask" src="<?php echo base_url()?>assets/nmps/images/portfolio-mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/4.jpg" alt="" title="">
                                <div class="image-overlay">
                                    <a href="<?php echo base_url()?>assets/nmps/images/4.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="portfolio-detail">
                                <div class="portfolio-title">
                                  
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!--dt-sc-portfolio-container ends-->
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>