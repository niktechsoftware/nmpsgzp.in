<?php
$this->load->view("include/nmps/header");
$this->load->view($body);
$this->load->view("include/nmps/footer");
?>