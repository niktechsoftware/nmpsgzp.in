<?php
$this->load->view("include/nmda/header");
$this->load->view($body);
$this->load->view("include/nmda/footer");
?>