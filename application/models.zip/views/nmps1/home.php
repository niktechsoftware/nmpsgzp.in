   <div id="main">
        
            <!--slider starts-->
            <div id="slider"> 
                <div id="layerslider_4" class="ls-wp-container" style="width:100%;height:610px;max-width:1920px;margin:0 auto;margin-bottom: 0px;">
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps/images/layerslider-gallery/bg3.jpg" class="ls-bg" alt="Slide background" />
                        <img class="ls-l" style="top:120px;left:530px;white-space: nowrap;" data-ls="offsetxin:0;delayin:800;easingin:easeOutElastic;skewxin:30;skewyin:30;transformoriginin:50% 0% 50%;offsetxout:0;parallaxlevel:1;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/bring.png" alt="">
                        <img class="ls-l" style="top:420px;left:-375px;z-index:100;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:80;delayin:500;offsetxout:0;offsetyout:-80;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/grass.png" alt="">
                        <img class="ls-l" style="top:185px;left:530px;white-space: nowrap;" data-ls="offsetxin:2;delayin:1000;rotatexin:90;rotateyin:90;offsetxout:0;parallaxlevel:-1;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/fun.png" alt="">
                        <img class="ls-l" style="top:252px;left:507px;white-space: nowrap;" data-ls="offsetxin:0;delayin:1800;scalexin:3;scaleyin:3;offsetxout:0;parallaxlevel:-2;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/two.png" alt="">
                        <img class="ls-l" style="top:250px;left:571px;white-space: nowrap;" data-ls="offsetxin:0;delayin:2200;rotatexin:90;rotateyin:90;offsetxout:0;parallaxlevel:3;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/life.png" alt="">
                        <img class="ls-l" style="top:355px;left:518px;white-space: nowrap;" data-ls="delayin:2500;parallaxlevel:-2;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/cup-divider.png" alt="">
                        <img class="ls-l" style="top:405px;left:509px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:-100;delayin:3000;offsetxout:0;offsetyout:100;parallaxlevel:3;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/a-trendy-kids.png" alt="">
                      
                        <img class="ls-l" style="top:70px;left:-79px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:150;delayin:2700;easingin:easeInBack;offsetxout:0;offsetyout:-150;parallaxlevel:5;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/girl1.png" alt="">
                        <img class="ls-l" style="top:85px;left:955px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:150;delayin:2500;offsetxout:0;offsetyout:-150;parallaxlevel:4;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/boy3.png" alt="">
                    </div>
                  
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/black-board.jpg" class="ls-bg" alt="Slide background" />
                        <img class="ls-l" style="top:35px;left:100px;white-space: nowrap;" data-ls="offsetxout:180;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/school-kid.png" alt="">
                        <img class="ls-l" style="top:23px;left:998px;white-space: nowrap;" data-ls="delayin:1500;scaleyin:3;transformoriginin:0% 50% 0;parallaxlevel:2;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/b-cloud.png" alt="">
                        <img class="ls-l" style="top:67px;left:679px;white-space: nowrap;" data-ls="offsetxin:0;offsetyin:-100;delayin:2000;rotateyin:30;parallaxlevel:5;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/b-swirl.png" alt="">
                        <img class="ls-l" style="top:78px;left:450px;white-space: nowrap;" data-ls="offsetxin:-200;delayin:2000;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/b-comment.png" alt="">
                        <img class="ls-l" style="top:137px;left:498px;white-space: nowrap;" data-ls="delayin:2500;rotateyin:30;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/welcome-text.png" alt="">
                        <img class="ls-l" style="top:222px;left:496px;white-space: nowrap;" data-ls="delayin:3000;rotateyin:30;" src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/text-desc.png" alt="">
                       
                    </div>
                    
                    
                    <div class="ls-slide" data-ls="slidedelay:7000; transition2d: all;">
                        <img src="<?php echo base_url()?>assets/nmps//images/layerslider-gallery/bg2.jpg" class="ls-bg" alt="Slide background" />
                      
                    </div>
                </div>
            </div>
            <!--slider ends-->

            <!--primary starts-->
            <section id="primary" class="content-full-width">
                <!--container starts-->
                <div class="container">
                    
                    <div class="dt-sc-one-fourth column first">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps//images/service1.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">About NMPS</a></h4>
                            <p>A different school besides the unprecedented academic result New Modern Public School is known for inculcating in its students a spiritual outlook and a global vision.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps//images/service2.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Admission Procedure</a></h4>
                            <p>The new academic session commences every year in April. All the students seeking admission to differnt classes are required to register themselves for admission.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps//images/service3.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Admission Age</a></h4>
                            <p> The required age of a child for admission to a particular class as on 1st April for the session should be as under.</p>
                        </div>
                    </div>
                    
                    <div class="dt-sc-one-fourth column">
                        <div class="dt-sc-ico-content type1">
                            <div class="icon">
                                <span class="icon-outer">
                                    <img src="<?php echo base_url()?>assets/nmps//images/service4.jpg" alt="" title="">
                                    <span class="infolayer">
                                        <a href="#"><i class="fa fa-link"></i></a>
                                    </span>
                                </span>
                            </div>
                            <h4><a href="#">Office Timing</a></h4>
                            <table><tr><th>morning</th><th>Evening</th></tr><tr><tr><td>6:30 am to 1:15 pm</td><td>3:15 pm to 5:30 pm</td></tr></table>
                        </div>
                    </div>
                    
                </div>
                <!--container ends-->
                <div class="dt-sc-hr"></div>
              
                <div class="dt-sc-hr"></div>
                <!--container starts-->
                <div class="container">
                    <h2 class="dt-sc-hr-green-title">Our Portfolio</h2>
                    
                    <!--portfolio-content starts-->
                    <div class="front-portfolio-container">
                       <div class="portfolio-content portfolio-content1">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                  	  <img src="<?php echo base_url()?>assets/nmps//images/image1.jpg" alt="" title="">
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image1.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                       <div class="portfolio-content portfolio-content2">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                  	  <img src="<?php echo base_url()?>assets/nmps//images/image2.jpg" alt="" title="">	
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image2.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                      
                       <div class="portfolio-content portfolio-content3">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                      <img src="<?php echo base_url()?>assets/nmps//images/image3.jpg" alt="" title="">
                                      <div class="image-overlay">
                                        <h5><a href="#l">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image3.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                       
                       <div class="portfolio-content portfolio-content4">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                      <img src="<?php echo base_url()?>assets/nmps//images/image4.jpg" alt="" title="">
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image4.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                      
                       <div class="portfolio-content portfolio-content5">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                      <img src="<?php echo base_url()?>assets/nmps//images/image5.jpg" alt="" title="">
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="<#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image5.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                      
                       <div class="portfolio-content portfolio-content6">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                      <img src="<?php echo base_url()?>assets/nmps//images/image6.jpg" alt="" title="">
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image6.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                              
                       <div class="portfolio-content portfolio-content7">
                           <div class="front-portfolio">
                              <div class="portfolio-outer">
                                  <div class="portfolio-thumb">
                                      <img src="<?php echo base_url()?>assets/nmps//images/image7.jpg" alt="" title=""> 		
                                      <div class="image-overlay">
                                        <h5><a href="#">Gifts at Large</a></h5>
                                        <a href="#" class="link"><span class="fa fa-link"></span></a>
                                        <a href="<?php echo base_url()?>assets/nmps//images/image7.jpg" data-gal="prettyPhoto[gallery]" class="zoom"><span class="fa fa-search"></span></a>
                                    </div>
                                  </div>
                              </div>
                           </div>
                       </div>
                       <div class="dt-sc-hr-small"></div>
                       <div class="aligncenter">
                           <a href="#" class="dt-sc-button medium mustard"> Hit here to view all <span class="fa fa-chevron-circle-right"> </span></a>        
                       </div>
                    </div>
                       
                    <!--front-portfolio-container ends-->
                    
                </div>
                <!--container ends-->
                
                <div class="dt-sc-hr"></div>
              
               
              
            </section>
            <!--primary ends-->
        </div>
        