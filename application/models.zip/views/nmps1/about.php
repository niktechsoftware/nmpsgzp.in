<div id="main">
        	<!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
            	<div class="container">
                	<h1>About us</h1>
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
            	<!--primary starts-->
            	<section id="primary" class="content-full-width">
                    
                    <div class="column dt-sc-one-half first">
                    	<div class="about-slider-wrapper">
                            <ul class="about-slider">
                                <li> <img src="<?php echo base_url()?>assets/nmps/images/activity1.jpg" alt="" title=""> </li>
                                <li> <img src="<?php echo base_url()?>assets/nmps/images/activity2.jpg" alt="" title=""> </li>
                                <li> <img src="<?php echo base_url()?>assets/nmps/images/activity3.jpg" alt="" title=""> </li>
                            </ul>
                        </div>	
                    </div>
                    
                    <!--dt-sc-one-half starts-->
                     <div class="column dt-sc-one-half">
                        <div class="dt-sc-titled-box green">
                            <h4 class="dt-sc-titled-box-title"> Introduction </h4>
                            <div class="dt-sc-titled-box-content">
                               <p>After providing full satisfaction throught New Modern Coaching Centre. I would like to explore new concept for basic establishment for children to set up New Modern Public School, Fullanpur, Ghazipur. We are dedicated to quality based educatin with testing of growth of intelligence through individual attention to students with spoken English skill and computer.</p>
                       <p>Modern life is becoming increasingly complex and society tha lays on developing human resources from grass roots will ultimately become sucessful. With these ideas New Modern Public Schook has made a modest begining is providing excellent quality school education in English Medium in backward area where most children are first generation learns. The term facilities and mythologies that have been a dooped in charting hitherto unexplored vistas are briefly given in the prospectus.</p>  
                    </div> 
                        </div>
                    </div>
                   
                   
                    <!--dt-sc-one-half starts-->
                   
                   <section id="primary" class="content-full-width">
                    
                    <div class="column dt-sc-one-half first">
                        <div class="dt-sc-titled-box">
                            <h4 class="dt-sc-titled-box-title">AIMS AND OBJECTIVES</h4>
                            <div class="dt-sc-titled-box-content">
                               Our school's aim is Educations , "dedication and service" the pupils of this school are imparted such type of education, the process of which tends to train the complete man to the excellence of all his\her natural and supernatural faculties and talents so that so that he\she may prove a promoter of all things and act embraced by our motto.
                            </div>
                        </div>
                    </div>
                    
                    <div class="column dt-sc-one-half">
                        <div class="dt-sc-titled-box green">
                            <h4 class="dt-sc-titled-box-title"> NEW MODERN PUBLIC SCHOOL </h4>
                            <div class="dt-sc-titled-box-content">
                               A different school besides the unprecedented academic result New Modern Public School is known for inculcating in its students a spiritual outlook and a global vision. it teaches them to reverence for all people and religions of the world and prepares them to serve humanity at large. Students are not only prepared for exams but for lief itself to become conscious and contribution member society.<br><br>
                                         New modern Public School is a forward looking school it teaches its children the value of unity, peace and inspires them to become ideal citizens.<br><br>
                                       it believe that true education releases capacities develops analytical abilities, self confidence, will power and goal setting compact. Legacies and instills the vision that enables one to become self motivated agent of social change serving the best intrests of the community. it trains the children to become good at heart and smart in thoughts and actions.
                                         
                            </div>
                        </div>
                    </div>
                    </section>
                   
                    <!--dt-sc-one-half ends--> 
                    
                    <div class="dt-sc-hr"></div>
                    
                    <h2 class="dt-sc-hr-green-title">Our Teachers</h2>
                    <div class="column dt-sc-one-fourth first">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/team1.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-facebook"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-twitter"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Jack Daniels </h4>
                                <h6> Senior Supervisor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/team2.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-facebook"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-twitter"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Linda Glendell </h4>
                                <h6> Teaching Professor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/team3.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-facebook"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-twitter"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kate Dennings </h4>
                                <h6> Children Diet </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="<?php echo base_url()?>assets/nmps/images/team4.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-facebook"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-twitter"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kristof Slinghot </h4>
                                <h6> Management </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    
                    
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>