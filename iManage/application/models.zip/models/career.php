<?php
	class career extends CI_Model{
		
	}